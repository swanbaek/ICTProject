package ex07;

public interface Service {

	void test1();
}
