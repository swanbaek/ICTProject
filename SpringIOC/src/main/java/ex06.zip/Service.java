package ex06;

public interface Service {
	
	void test1();
	void test2();
	void test3();
	void test4();

}
