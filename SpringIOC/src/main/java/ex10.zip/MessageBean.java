package ex10;

public interface MessageBean {
	
	void sayHello();
	void sayHi(String ... args);

}
